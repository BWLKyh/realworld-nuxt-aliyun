import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _c0228440 = () => interopDefault(import('../layouts' /* webpackChunkName: "" */))
const _647973d4 = () => interopDefault(import('../pages/error' /* webpackChunkName: "" */))
const _1a8a2cda = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _64da9135 = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _71a1e875 = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _53db36d7 = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _29ebb921 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _586c2bc2 = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _c0228440,
    children: [{
      path: "/error",
      component: _647973d4,
      name: "error"
    }, {
      path: "",
      component: _1a8a2cda,
      name: "home"
    }, {
      path: "/login",
      component: _64da9135,
      name: "login"
    }, {
      path: "/register",
      component: _64da9135,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _71a1e875,
      name: "profile"
    }, {
      path: "/settings",
      component: _53db36d7,
      name: "settings"
    }, {
      path: "/editor",
      component: _29ebb921,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _586c2bc2,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
